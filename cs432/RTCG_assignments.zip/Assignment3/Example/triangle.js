"use strict";
var canvas;
var gl;
var pentagons = [];
        var pentagonColor = [];

var maxNumTriangles = 200;
var maxNumPositions  = 3*maxNumTriangles;
var index = 0;

var newPentagon = vec2(10,10);
var maxNumPentagons = 200;
var maxNumPositions  = 9*maxNumPentagons;

//Global variables to keep track of pentagons which are created dynamically 


//Pentagons (just color here. The pentagon vertex creation happens in the left click event)
var colors = [
    vec4(0.0, 0.0, 0.0, 1.0),  // black
    vec4(1.0, 0.0, 0.0, 1.0 ),  // red
    vec4(1.0, 1.0, 0.0, 1.0),  // yellow
    vec4(0.0, 1.0, 0.0, 1.0),  // green
    vec4(0.0, 0.0, 1.0, 1.0),  // blue
    vec4(1.0, 0.0, 1.0, 1.0),  // magenta
    vec4(0.0, 1.0, 1.0, 1.0)   // cyan
];

window.onload = function init() {

    canvas = document.getElementById("gl-canvas");

    gl = canvas.getContext('webgl2');
    if (!gl) alert("WebGL 2.0 isn't available");


    
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(0.8, 0.8, 0.8, 1.0);

    //
    //  Load shaders and initialize attribute buffers
    //
    var program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);


    //Send Color array
    var cBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, cBuffer );
    cBuffer.__SPECTOR_Metadata = {name : "color Buffer"};
    gl.bufferData( gl.ARRAY_BUFFER, 16 * maxNumPositions, gl.STATIC_DRAW );

    var shaderType = gl.getUniformLocation( program, "shaderType" );
    gl.uniform1i(shaderType,2);
    var aColor = gl.getAttribLocation( program, "aColor" );
    gl.vertexAttribPointer( aColor, 3, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray(aColor);

    //Send Vertex array
    var vBuffer = gl.createBuffer();
    vBuffer.__SPECTOR_Metadata = {name : "vertex Buffer"};
    gl.bindBuffer( gl.ARRAY_BUFFER, vBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, 8 * maxNumPositions, gl.STATIC_DRAW );
    // Associate out shader variable with our data buffer
    var aPosition = gl.getAttribLocation( program, "aPosition" );
    gl.vertexAttribPointer( aPosition, 2, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray(aPosition);


    canvas.addEventListener("click", function(){

        

        gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
        var t = vec2(2*event.clientX/canvas.width-1,
             2*(canvas.height-event.clientY)/canvas.height-1);

        var cX = -0.6;
        var cY = 0.67;
        var r = 0.1 //Radius
        var i = 0;
        //Generate distinct verticies we need for the pentagon
        var pentagonsTemp = [];
        for (i = 0; i <= 4; i++){
            pentagonsTemp.push(vec2(
                r*Math.cos(i*2*Math.PI/5 ) + t[0],
                r*Math.sin(i*2*Math.PI/5 ) + t[1]
            ));
        }


        //Create the pentagon vertex list in traingles
        pentagons.push(pentagonsTemp[0]);
        pentagons.push(pentagonsTemp[1]);
        pentagons.push(pentagonsTemp[2]);
        pentagons.push(pentagonsTemp[2]);
        pentagons.push(pentagonsTemp[3]);
        pentagons.push(pentagonsTemp[4]);
        pentagons.push(pentagonsTemp[4]);
        pentagons.push(pentagonsTemp[0]);
        pentagons.push(pentagonsTemp[2]);

        //gl.bufferSubData(gl.ARRAY_BUFFER, 8*index, flatten(pentagonsTemp));
        gl.bufferData( gl.ARRAY_BUFFER, flatten(pentagons), gl.STATIC_DRAW );

        gl.bindBuffer( gl.ARRAY_BUFFER, cBuffer);
        var color = colors[index%5];
        
        for(i = 0; i < 9; i++)
        {
            pentagonColor.push(color);
        }
        
        //gl.bufferSubData(gl.ARRAY_BUFFER, 16*index, flatten(color));
        gl.bufferData(gl.ARRAY_BUFFER, flatten(pentagonColor), gl.STATIC_DRAW);
        index++;
    });


    render();
}


function render() {

    gl.clear(gl.COLOR_BUFFER_BIT);
    for(var i = 0; i < index; i++) {

        gl.drawArrays( gl.TRIANGLES, i * 9,  9 ); 
    }

    requestAnimationFrame(render);
}
