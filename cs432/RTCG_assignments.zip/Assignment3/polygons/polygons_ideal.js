
//Interactivity:
var circleRadius = 100;
var rotateEllipse = 1;
var squareAltcolor = vec3(1.0,1.0,1.0);
var ellipseAltcolor = vec3(1.0,0.0,0.0);
var newPentagon = vec2(10,10);

var maxNumPentagons = 200;
var maxNumPositions  = 9*maxNumPentagons;

var programEllipse;
var programCircle;
var programSquare;
var programTriangle;
var programPentagon;

//WebGL Graphics Variables:

var canvas;
var gl;

var index = 0;

//Global variables to keep track of pentagons which are created dynamically 
var pentagons = [];
var pentagonColor = [];

function init() 
{

    canvas = document.getElementById( "gl-canvas" );

    gl = canvas.getContext('webgl2');
    if ( !gl ) { alert( "WebGL 2.0 isn't available" ); }


    var vertices = [];
    var ellipseColors = [];
    var shadedCircleColors = [];
    var shadedCircle = [];
    var triColors = [];
    var triangle = [];
    var squareColor = [];
    var square = [];
    var colors = [];

    //Ellipse
    var cX = -0.6;
    var cY = 0.67;
    var r = 0.25 //Radius
    vertices = [];

    vertices.push(vec2(cX, cY));
    ellipseColors.push(ellipseAltcolor);
    for (i = 0; i <= 50; i++){
        if(rotateEllipse)
        {
            vertices.push(vec2(
                r*Math.cos(i*2*Math.PI/50 ) + cX,
                r*Math.sin(i*2*Math.PI/50 ) * 0.5 + cY
            ));
        }
        else
        {
            vertices.push(vec2(
                r*Math.cos(i*2*Math.PI/50 ) * 0.5 + cX,
                r*Math.sin(i*2*Math.PI/50 ) + cY
            ));
        }
        ellipseColors.push(ellipseAltcolor);
    }

    gl.clearColor( 0.0, 0.0, 0.0, 1.0 );
    programEllipse = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram(programEllipse);

    //Send Color array
    var shaderType = gl.getUniformLocation( programEllipse, "shaderType" );
    var cBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, cBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(ellipseColors), gl.STATIC_DRAW );

    
    gl.uniform1i(shaderType,2);
    var aColor = gl.getAttribLocation( programEllipse, "aColor" );
    gl.enableVertexAttribArray(aColor);
    gl.vertexAttribPointer( aColor, 3, gl.FLOAT, false, 0, 0 );

    // Load the data into the GPU and send vertex array
    var bufferId = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, bufferId );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(vertices), gl.STATIC_DRAW );

    var aPosition = gl.getAttribLocation( programEllipse, "aPosition" );
    gl.enableVertexAttribArray(aPosition);
    gl.vertexAttribPointer( aPosition, 2, gl.FLOAT, false, 0, 0 );





    programCircle = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram(programCircle);


    //Shaded circle
    shadedCircleColors = [];
    shadedCircle = [];
    cX = 0.6;
    r = 0.25 * circleRadius / 100;
    shadedCircle.push(vec2(cX + r,cY))
    shadedCircleColors.push(vec3(0,0,0))
    for (i = 0; i <= 50; i++){
        shadedCircle.push(vec2(
            r*Math.cos(i*2*Math.PI/50) + cX,
            r*Math.sin(i*2*Math.PI/50) + cY
        ));
        shadedCircleColors.push(vec3(i/50,0,0))
    }

    //SHADED CIRCLE

 
    //Init program with color shade shaders
    //Send Color array
    var circle_cBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, circle_cBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(shadedCircleColors), gl.STATIC_DRAW );

    var shaderType = gl.getUniformLocation( programCircle, "shaderType" );
    gl.uniform1i(shaderType,2);
    var circle_aColor = gl.getAttribLocation( programCircle, "aColor" );
    gl.enableVertexAttribArray(circle_aColor);
    gl.vertexAttribPointer( circle_aColor, 3, gl.FLOAT, false, 0, 0 );
    

    //Send Vertex array
    bufferId = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, bufferId );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(shadedCircle), gl.STATIC_DRAW );
    // Associate out shader variable with our data buffer
    var circle_aPosition = gl.getAttribLocation( programCircle, "aPosition" );
    gl.enableVertexAttribArray(circle_aPosition);
    gl.vertexAttribPointer( circle_aPosition, 2, gl.FLOAT, false, 0, 0 );
    



   /*

    programTriangle = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram(programTriangle);


    //Gradient Colored Triangle
    triangle = [];
    cX = 0;
    cY = 0.6;
    r = 0.35

    triangle.push(vec2(cX,cY))
    for (i = 0; i <= 2; i++){
        triangle.push(vec2(
            r*Math.cos(i*2*Math.PI/3 - 2*Math.PI/12) + cX,
            r*Math.sin(i*2*Math.PI/3 - 2*Math.PI/12) + cY
        ));
    }

    triangle.push(triangle[1]);
    triColors = [
        vec3( 0.5, 0.5, 0.5 ),
        vec3( 0.0, 0.0, 1.0 ),
        vec3( 1.0, 0.0, 0.0 ),
        vec3( 0.0, 1.0, 0.0 ),
        vec3( 0.0, 0.0, 1.0 )
    ];

    //Send Color array
    var cBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, cBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(triColors), gl.STATIC_DRAW );

    var shaderType = gl.getUniformLocation( programTriangle, "shaderType" );
    gl.uniform1i(shaderType,2);
    var aColor = gl.getAttribLocation( programTriangle, "aColor" );
    gl.vertexAttribPointer( aColor, 3, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray(aColor);

    //Send Vertex array
    bufferId = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, bufferId );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(triangle), gl.STATIC_DRAW );
    // Associate out shader variable with our data buffer
    aPosition = gl.getAttribLocation( programTriangle, "aPosition" );
    gl.vertexAttribPointer( aPosition, 2, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray(aPosition);







    programSquare = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram(programSquare);

    //Square
    square = [];
    squareColor = [];
    cX = 0
    cY = -0.2;
    r = 0.75;
    toggle = true

    for(j = 0; j < 6; j++)
    {
        for (i = 1; i <= 4; i++){
            square.push(vec2(
                r*Math.cos(i*2*Math.PI/4 - 2*Math.PI/8) + cX,
                r*Math.sin(i*2*Math.PI/4 - 2*Math.PI/8) + cY
            ));
        }
        

        if(toggle)
        {
            squareColor.push(squareAltcolor);
            squareColor.push(squareAltcolor);
            squareColor.push(squareAltcolor);
            squareColor.push(squareAltcolor);
        }
        else
        {
            squareColor.push(vec3(0.0, 0.0, 0.0));
            squareColor.push(vec3(0.0, 0.0, 0.0));
            squareColor.push(vec3(0.0, 0.0, 0.0));
            squareColor.push(vec3(0.0, 0.0, 0.0));
        }
        toggle = !toggle;
        r -= 0.12
    }                
    var cBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, cBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(squareColor), gl.STATIC_DRAW );

    var shaderType = gl.getUniformLocation( programSquare, "shaderType" );
    gl.uniform1i(shaderType,2);
    var aColor = gl.getAttribLocation( programSquare, "aColor" );
    gl.vertexAttribPointer( aColor, 3, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray(aColor);

    //Send Vertex array
    var bufferId = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, bufferId );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(square), gl.STATIC_DRAW );
    // Associate out shader variable with our data buffer
    var aPosition = gl.getAttribLocation( programSquare, "aPosition" );
    gl.vertexAttribPointer( aPosition, 2, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray(aPosition);






    programPentagon = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram(programPentagon);

    //Pentagons (just color here. The pentagon vertex creation happens in the left click event)
    var colorPallete = [

        vec3(0.0, 1.0, 1.0),  //
        vec3(1.0, 0.0, 0.0),  // red
        vec3(1.0, 1.0, 0.0),  // yellow
        vec3(0.0, 1.0, 0.0),  // green
        vec3(0.0, 0.0, 1.0),  // blue
        vec3(1.0, 0.0, 1.0),  // magenta
    ];

    var colors = colorPallete;
    //Send Color array
    var cBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, cBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, 16 * maxNumPositions, gl.STATIC_DRAW );

    var shaderType = gl.getUniformLocation( programPentagon, "shaderType" );
    gl.uniform1i(shaderType,2);
    var aColor = gl.getAttribLocation( programPentagon, "aColor" );
    gl.vertexAttribPointer( aColor, 3, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray(aColor);

    //Send Vertex array
    var vBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, vBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, 8 * maxNumPositions, gl.STATIC_DRAW );
    // Associate out shader variable with our data buffer
    aPosition = gl.getAttribLocation( programPentagon, "aPosition" );
    gl.vertexAttribPointer( aPosition, 2, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray(aPosition);

    gl.viewport( 0, 0, canvas.width, canvas.height );
    

    //Left click event - pentagons drawing will only update when the event is hit
    canvas.addEventListener("click", function(){

        gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer)

        newPentagon = vec2(2*event.clientX/canvas.width-1,
            2*(canvas.height-event.clientY)/canvas.height-1);

        var cX = -0.6;
        var cY = 0.67;
        var r = 0.1 //Radius
        //Generate distinct verticies we need for the pentagon
        var pentagonsTemp = [];
        for (i = 0; i <= 4; i++){
            pentagonsTemp.push(vec2(
                r*Math.cos(i*2*Math.PI/5 ) + newPentagon[0],
                r*Math.sin(i*2*Math.PI/5 ) + newPentagon[1]
            ));
        }
        //Create the pentagon vertex list in traingles
        pentagons.push(pentagonsTemp[0]);
        pentagons.push(pentagonsTemp[1]);
        pentagons.push(pentagonsTemp[2]);
        pentagons.push(pentagonsTemp[2]);
        pentagons.push(pentagonsTemp[3]);
        pentagons.push(pentagonsTemp[4]);
        pentagons.push(pentagonsTemp[4]);
        pentagons.push(pentagonsTemp[0]);
        pentagons.push(pentagonsTemp[2]);


        gl.bufferData(gl.ARRAY_BUFFER, flatten(pentagons), gl.STATIC_DRAW );
        
        gl.bindBuffer(gl.ARRAY_BUFFER, cBuffer)
        var color = vec3(colors[index%6]);
        for(i = 0; i < 9; i++)
        {
            pentagonColor.push(color);
        }
        gl.bufferData(gl.ARRAY_BUFFER, flatten(pentagonColor), gl.STATIC_DRAW );
        
        index++;

    });

    */


    render();
};


var aColor;
var cBuffer;
var aPosition;
var bufferId;




function render() 
{
    gl.clear(gl.COLOR_BUFFER_BIT);

    gl.useProgram(programEllipse);

    //I think we are supposed to do the below down here
/*
    var shaderType = gl.getUniformLocation( programEllipse, "shaderType" );
    gl.uniform1i(shaderType,2);
    var aColor = gl.getAttribLocation( programEllipse, "aColor" );
    gl.enableVertexAttribArray(aColor);
    gl.vertexAttribPointer( aColor, 3, gl.FLOAT, false, 0, 0 );

    var aPosition = gl.getAttribLocation( programEllipse, "aPosition" );
    gl.enableVertexAttribArray(aPosition);
    gl.vertexAttribPointer( aPosition, 2, gl.FLOAT, false, 0, 0 );

*/


    gl.drawArrays( gl.TRIANGLE_FAN, 0, 52 );

 
    
    gl.useProgram(programCircle);
    gl.drawArrays( gl.TRIANGLE_FAN, 0, 52 );
       /*

    //DRAW
    //COLOR GRADIENT TRIANGLE
    gl.useProgram(programTriangle);
    gl.drawArrays( gl.TRIANGLE_FAN, 0, 5 );


    //DRAW
    //SQAURES

    //Send Color array
    gl.useProgram(programSquare);   
    gl.drawArrays( gl.TRIANGLE_FAN, 0, 4 );
    gl.drawArrays( gl.TRIANGLE_FAN, 4, 4 );
    gl.drawArrays( gl.TRIANGLE_FAN, 8, 4 );
    gl.drawArrays( gl.TRIANGLE_FAN, 12, 4 );
    gl.drawArrays( gl.TRIANGLE_FAN, 16, 4 );
    gl.drawArrays( gl.TRIANGLE_FAN, 20, 4 );


    //DRAW
    //PENTAGONS

    gl.useProgram(programPentagon);
 
    for(var i = 0; i < index; i++) {

        gl.drawArrays( gl.TRIANGLES, i * 9,  9 ); 
    }
    */

    requestAnimationFrame(render);
};


//Onload function
window.onload = init();


//Interactivity functions:

document.getElementById("circleRadius").onchange = function()
{
    circleRadius = document.getElementById("circleRadius").value;
    output = document.getElementById("output");
    output.innerHTML = "Radius: " + circleRadius; 
    init();
};

document.getElementById("ellipseRotate90").onclick = function()
    { rotateEllipse = !rotateEllipse;
      init();
    
    };

newColor = document.getElementById("squareColor");
newColor.onchange = function()
{
switch(newColor.selectedIndex)
{
    case 0:
        squareAltcolor = vec3(1.0,0.0,0.0)
        break;
    case 1:
        squareAltcolor = vec3(0.5,0.8,0.9)
        break;
    case 2:
        squareAltcolor = vec3(0.0,0.5,0.5)
        break;
    case 3:
        squareAltcolor = vec3(1.0,1.0,1.0)
        break;
    default:
        break;
}
init();
};

window.addEventListener("keydown", function() {
    switch (event.key) {
    case "r": // ’r’ key
        ellipseAltcolor = vec3(1.0,0.0,0.0);
        break;
    case "g": // ’g’ key
        ellipseAltcolor = vec3(0.0,1.0,0.0);
        break;
    case "b": // ’b’ key
        ellipseAltcolor = vec3(0.0,0.0,1.0);
        break;
    case "y": // ’y’ key
        ellipseAltcolor = vec3(1.0,1.0,0.0);
        break;
    case "p": // ’p’ key
        ellipseAltcolor = vec3(0.5,0.0,0.5);
        break;
    case "w": // ’w’ key
        ellipseAltcolor = vec3(1.0,1.0,1.0);
        break;
    default:
        break;
    }
    init();
});
