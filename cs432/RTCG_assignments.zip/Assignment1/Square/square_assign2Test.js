
var canvas;
var gl;

window.onload = function init() {
    canvas = document.getElementById( "gl-canvas" );

    gl = gl = canvas.getContext('webgl2');
    if ( !gl ) { alert( "WebGL 2.0 isn't available" ); }

    // Four Vertices

//Vertices
var cX = -0.6;
var cY = 0.67;
var r = 0.25 //Radius
var vertices = [];

vertices.push(vec2(cX, cY));
for (i = 0; i <= 50; i++){
    vertices.push(vec2(
        r*Math.cos(i*2*Math.PI/50) + cX,
        r*Math.sin(i*2*Math.PI/50) * 0.5 + cY
    ));
}

var shadedCircleColors = [];
var shadedCircle = [];
cX = 0.6;
shadedCircle.push(vec2(cX,cY))
shadedCircleColors.push(vec3(0,0,0))
for (i = 0; i <= 50; i++){
    shadedCircle.push(vec2(
        r*Math.cos(i*2*Math.PI/50) + cX,
        r*Math.sin(i*2*Math.PI/50) + cY
    ));
    shadedCircleColors.push(vec3(i/50,0,0))
}


var triangle = [];
cX = 0;
cY = 0.6;
r = 0.35
//Why doesn't this work?
triangle.push(vec2(cX,cY))
for (i = 0; i <= 2; i++){
    triangle.push(vec2(
        r*Math.cos(i*2*Math.PI/3 - 2*Math.PI/12) + cX,
        r*Math.sin(i*2*Math.PI/3 - 2*Math.PI/12) + cY
    ));
}
//Why doesn't this work?
triangle.push(triangle[1]);
var triColors = [
    vec3( 0.0, 0.0, 1.0 ),
    vec3( 1.0, 0.0, 0.0 ),
    vec3( 0.0, 1.0, 0.0 )
];


     //  Configure WebGL

 gl.viewport( 0, 0, canvas.width, canvas.height );
 gl.clearColor( 0.0, 0.0, 0.0, 1.0 );

  //  Load shaders and initialize attribute buffers

 var program = initShaders( gl, "vertex-shader", "fragment-shader" );
 gl.useProgram( program );

  // Load the data into the GPU

 var bufferId = gl.createBuffer();
 gl.bindBuffer( gl.ARRAY_BUFFER, bufferId );
 gl.bufferData( gl.ARRAY_BUFFER, flatten(triangle), gl.STATIC_DRAW );

  // Associate out shader variable with our data buffer

 var aPosition = gl.getAttribLocation( program, "aPosition" );
 gl.vertexAttribPointer( aPosition, 2, gl.FLOAT, false, 0, 0 );
 gl.enableVertexAttribArray(aPosition);

     render();
};

function render() {
    gl.clear( gl.COLOR_BUFFER_BIT );
    gl.drawArrays( gl.TRIANGLE_FAN, 0, 5 );
}
