
var canvas;
var gl;

window.onload = function init() {
canvas = document.getElementById( "gl-canvas" );

gl = canvas.getContext('webgl2');
if ( !gl ) { alert( "WebGL 2.0 isn't available" ); }

//Vertices
var cX = -0.6;
var cY = 0.67;
var r = 0.25 //Radius
var vertices = [];

vertices.push(vec2(cX, cY));
for (i = 0; i <= 50; i++){
    vertices.push(vec2(
        r*Math.cos(i*2*Math.PI/50) + cX,
        r*Math.sin(i*2*Math.PI/50) * 0.5 + cY
    ));
}

var shadedCircleColors = [];
var shadedCircle = [];
cX = 0.6;
shadedCircle.push(vec2(cX,cY))
shadedCircleColors.push(vec3(0,0,0))
for (i = 0; i <= 50; i++){
    shadedCircle.push(vec2(
        r*Math.cos(i*2*Math.PI/50) + cX,
        r*Math.sin(i*2*Math.PI/50) + cY
    ));
    shadedCircleColors.push(vec3(i/50,0,0))
}


var triangle = [];
cX = 0;
cY = 0.6;
r = 0.35
//Why doesn't this work?
triangle.push(vec2(cX,cY))
for (i = 0; i <= 2; i++){
    triangle.push(vec2(
        r*Math.cos(i*2*Math.PI/3 - 2*Math.PI/12) + cX,
        r*Math.sin(i*2*Math.PI/3 - 2*Math.PI/12) + cY
    ));
}
//Why doesn't this work?
triangle.push(triangle[1]);
var triColors = [
    vec3( 0.0, 0.0, 1.0 ),
    vec3( 0.0, 0.0, 1.0 ),
    vec3( 0.0, 0.0, 1.0 ),
    vec3( 1.0, 0.0, 0.0 ),
    vec3( 0.0, 1.0, 0.0 )
];



var square1 = [
    vec2( -0.5, 0.3 ),
    vec2(  -0.5, -0.7 ),
    vec2(  0.5, -0.7 )
];
var square1_1 = [
    vec2( -0.5, 0.3 ),
    vec2(  0.5, -0.7 ),
    vec2(  0.5, 0.3 )
];
var square2 = [
    vec2( -0.4, 0.2 ),
    vec2(  -0.4, -0.6 ),
    vec2(  0.4, -0.6 )
];
var square2_1 = [
    vec2( -0.4, 0.2 ),
    vec2(  0.4, -0.6 ),
    vec2(  0.4, 0.2 )
];
var square3 = [
    vec2( -0.3, 0.1 ),
    vec2(  -0.3, -0.5 ),
    vec2(  0.3, -0.5 )
];
var square3_1 = [
    vec2( -0.3, 0.1 ),
    vec2(  0.3, -0.5 ),
    vec2(  0.3, 0.1 )
];
var square4 = [
    vec2( -0.2, 0.0 ),
    vec2(  -0.2, -0.4 ),
    vec2(  0.2, -0.4 )
];
var square4_1 = [
    vec2( -0.2, 0.0 ),
    vec2(  0.2, -0.4 ),
    vec2(  0.2, 0.0 )
];
var square5 = [
    vec2( -0.1, -0.1 ),
    vec2(  -0.1, -0.3 ),
    vec2(  0.1, -0.3 )
];
var square5_1 = [
    vec2( -0.1, -0.1 ),
    vec2(  0.1, -0.3 ),
    vec2(  0.1, -0.1 )
];



/*
//Triangle_fan method
var square = [];
cX = 0
cY = -0.2;
r = 0.6

for (i = 1; i <= 4; i++){
    square.push(vec2(
        r*Math.cos(i*2*Math.PI/4 - 2*Math.PI/8) + cX,
        r*Math.sin(i*2*Math.PI/4 - 2*Math.PI/8) + cY
    ));
}
*/


gl.viewport( 0, 0, canvas.width, canvas.height );
gl.clearColor( 0.0, 0.0, 0.0, 1.0 );

//  Load shaders and initialize attribute buffers


var program = initShaders( gl, "vertex-shader", "fragment-shader" );
gl.useProgram(program);

//Draw Red Ellpise
// Load the data into the GPU

 var bufferId = gl.createBuffer();
 gl.bindBuffer( gl.ARRAY_BUFFER, bufferId );
 gl.bufferData( gl.ARRAY_BUFFER, flatten(vertices), gl.STATIC_DRAW );

  // Associate out shader variable with our data buffer

 var shaderType = gl.getUniformLocation( program, "shaderType" );
 gl.uniform1i(shaderType,1);
 var aPosition = gl.getAttribLocation( program, "aPosition" );
 gl.vertexAttribPointer( aPosition, 2, gl.FLOAT, false, 0, 0 );
 gl.enableVertexAttribArray(aPosition);

    gl.clear( gl.COLOR_BUFFER_BIT );
    gl.drawArrays( gl.TRIANGLE_FAN, 0, 52 );



//Drawing shaded circle
 //Init program with color shade shaders

//Send Color array

var cBuffer = gl.createBuffer();
gl.bindBuffer( gl.ARRAY_BUFFER, cBuffer );
gl.bufferData( gl.ARRAY_BUFFER, flatten(shadedCircleColors), gl.STATIC_DRAW );

var shaderType = gl.getUniformLocation( program, "shaderType" );
 gl.uniform1i(shaderType,2);
var aColor = gl.getAttribLocation( program, "aColor" );
gl.vertexAttribPointer( aColor, 3, gl.FLOAT, false, 0, 0 );
gl.enableVertexAttribArray(aColor);

//Send Vertex array

bufferId = gl.createBuffer();
gl.bindBuffer( gl.ARRAY_BUFFER, bufferId );
gl.bufferData( gl.ARRAY_BUFFER, flatten(shadedCircle), gl.STATIC_DRAW );
// Associate out shader variable with our data buffer
aPosition = gl.getAttribLocation( program, "aPosition" );
gl.vertexAttribPointer( aPosition, 2, gl.FLOAT, false, 0, 0 );
gl.enableVertexAttribArray(aPosition);
    
    gl.drawArrays( gl.TRIANGLE_FAN, 0, 52 );




//Drawing Color Gradient Triangle


//Send Color array

var cBuffer = gl.createBuffer();
gl.bindBuffer( gl.ARRAY_BUFFER, cBuffer );
gl.bufferData( gl.ARRAY_BUFFER, flatten(triColors), gl.STATIC_DRAW );

var shaderType = gl.getUniformLocation( program, "shaderType" );
 gl.uniform1i(shaderType,2);
var aColor = gl.getAttribLocation( program, "aColor" );
gl.vertexAttribPointer( aColor, 3, gl.FLOAT, false, 0, 0 );
gl.enableVertexAttribArray(aColor);

//Send Vertex array

bufferId = gl.createBuffer();
gl.bindBuffer( gl.ARRAY_BUFFER, bufferId );
gl.bufferData( gl.ARRAY_BUFFER, flatten(triangle), gl.STATIC_DRAW );
// Associate out shader variable with our data buffer
aPosition = gl.getAttribLocation( program, "aPosition" );
gl.vertexAttribPointer( aPosition, 2, gl.FLOAT, false, 0, 0 );
gl.enableVertexAttribArray(aPosition);
    
    //Why doesn't this work?
    gl.drawArrays( gl.TRIANGLE_FAN, 0, 5 );
    //gl.drawArrays( gl.TRIANGLE_FAN, 0, 3 );





var bufferId = gl.createBuffer();
gl.bindBuffer( gl.ARRAY_BUFFER, bufferId );
gl.bufferData( gl.ARRAY_BUFFER, flatten(square1), gl.STATIC_DRAW );

 // Associate out shader variable with our data buffer

var shaderType = gl.getUniformLocation( program, "shaderType" );
gl.uniform1i(shaderType,4);
var aPosition = gl.getAttribLocation( program, "aPosition" );
gl.vertexAttribPointer( aPosition, 2, gl.FLOAT, false, 0, 0 );
gl.enableVertexAttribArray(aPosition);
gl.drawArrays( gl.TRIANGLES, 0, 3 );

gl.bufferData( gl.ARRAY_BUFFER, flatten(square1_1), gl.STATIC_DRAW );
gl.drawArrays( gl.TRIANGLES, 0, 3 );

gl.uniform1i(shaderType,3);
gl.bufferData( gl.ARRAY_BUFFER, flatten(square2), gl.STATIC_DRAW );
gl.drawArrays( gl.TRIANGLES, 0, 3 );
gl.bufferData( gl.ARRAY_BUFFER, flatten(square2_1), gl.STATIC_DRAW );
gl.drawArrays( gl.TRIANGLES, 0, 3 );

gl.uniform1i(shaderType,4);
gl.bufferData( gl.ARRAY_BUFFER, flatten(square3), gl.STATIC_DRAW );
gl.drawArrays( gl.TRIANGLES, 0, 3 );
gl.bufferData( gl.ARRAY_BUFFER, flatten(square3_1), gl.STATIC_DRAW );
gl.drawArrays( gl.TRIANGLES, 0, 3 );

gl.uniform1i(shaderType,3);
gl.bufferData( gl.ARRAY_BUFFER, flatten(square4), gl.STATIC_DRAW );
gl.drawArrays( gl.TRIANGLES, 0, 3 );
gl.bufferData( gl.ARRAY_BUFFER, flatten(square4_1), gl.STATIC_DRAW );
gl.drawArrays( gl.TRIANGLES, 0, 3 );

gl.uniform1i(shaderType,4);
gl.bufferData( gl.ARRAY_BUFFER, flatten(square5), gl.STATIC_DRAW );
gl.drawArrays( gl.TRIANGLES, 0, 3 );
gl.bufferData( gl.ARRAY_BUFFER, flatten(square5_1), gl.STATIC_DRAW );
gl.drawArrays( gl.TRIANGLES, 0, 3 );

};

