var canvas;
var gl;

var positions = [];
var colors = [];
var normals = [];


var xAxis = 0;
var yAxis = 1;
var zAxis = 2;

var centroid = [];
var relativeScaling = [];

var axis = 0;
var theta = [0, 0, 0];
var translate = [0, 0, 0];
var scale = [1, 1, 1];

var thetaLoc;
var translationLoc;
var scaleLoc;

var tType;
//var deltaAmt = [0.0001, 0.001, 0.0001];
var deltaAmt = [0.1, 0.1, 0.1];




window.onload = function init()
{
    canvas = document.getElementById("gl-canvas");

    gl = canvas.getContext('webgl2');
    if (!gl) alert("WebGL 2.0 isn't available");

    gl.clearColor( 0.0, 0.0, 0.0, 1.0 );

    gl.enable(gl.DEPTH_TEST);

    document.getElementById('files').onchange = function() 
    {
        positions = [];
        colors = [];
        normals = [];
        var verts = []; 
        var faces = [];
    
        var vert = [];
        var face = [];


        var file = this.files[0];
        var reader = new FileReader();
        reader.onload = function() 
        {
            var lines = this.result.split('\n');
            for (var line = 0; line < lines.length; line++)
            {
                var strings = lines[line].trimRight().split(' ');
                switch(strings[0])
                {
                    case('v'): 
                        vert = [strings[1], strings[2], strings[3]];
                        verts.push(vert)
                    break;
                    case('f'): // do more stuff
                        face = [strings[1] - 1, strings[2] - 1, strings[3] - 1];
                        faces.push(face);
                    break;
                }
            }


            //Calculate normal of vtxs for Gourand Shading (avg of surrounding face normals)
            var faceNormals;
            for(var vtx = 0; vtx < verts.length; vtx++)
            {
                faceNormals = [];
                for(var i = 0; i < faces.length; i++)
                {
                    if((faces[i][0] == vtx ) || (faces[i][1] == vtx ) || (faces[i][2] == vtx ))
                    {
                        var vtx0 = vec3(verts[faces[i][0]][0], verts[faces[i][0]][1], verts[faces[i][0]][2]);
                        var vtx1 = vec3(verts[faces[i][1]][0], verts[faces[i][1]][1], verts[faces[i][1]][2]);
                        var vtx2 = vec3(verts[faces[i][2]][0], verts[faces[i][2]][1], verts[faces[i][2]][2]);
                        var val1 = subtract(vtx1,vtx0);
                        var val2 = subtract(vtx2,vtx0);
                        var vtxNormal = cross(val1,val2);
                        
                        faceNormals.push(vtxNormal);
                    }
                }
                //average neighboring face normals and push to vertex normal list
                var summation = vec3(0,0,0);
                for(var i = 0; i < faceNormals.length; i++)
                {
                    summation = add(summation,faceNormals[i]);
                }
                normals.push(normalize(summation));
                
            }



            //Import model            
            for(var i = 0; i < faces.length; i++)
            {
                positions.push(vec4(verts[faces[i][0]][0],verts[faces[i][0]][1],verts[faces[i][0]][2],1),
                                vec4(verts[faces[i][1]][0],verts[faces[i][1]][1],verts[faces[i][1]][2],1),
                                vec4(verts[faces[i][2]][0],verts[faces[i][2]][1],verts[faces[i][2]][2],1));
                //Set color as normal vector
                colors.push(vec4(Math.abs(normals[faces[i][0]][0]),Math.abs(normals[faces[i][0]][1]),Math.abs(normals[faces[i][0]][2]),1),
                            vec4(Math.abs(normals[faces[i][1]][0]),Math.abs(normals[faces[i][1]][1]),Math.abs(normals[faces[i][1]][2]),1),
                            vec4(Math.abs(normals[faces[i][2]][0]),Math.abs(normals[faces[i][2]][1]),Math.abs(normals[faces[i][2]][2]),1));
                
            }

            //Determine Centroid
            var upperXYZ = [-9999,-9999,-9999]
            var lowerXYZ = [9999,9999,9999]
            for(var i = 0; i < verts.length; i++)
            {
                if(verts[i][0] < lowerXYZ[0])
                {
                    lowerXYZ[0] = verts[i][0];
                }
                if(verts[i][0] > upperXYZ[0])
                {
                    upperXYZ[0] = verts[i][0];
                }
                if(verts[i][1] < lowerXYZ[1])
                {
                    lowerXYZ[1] = verts[i][1];
                }
                if(verts[i][1] > upperXYZ[1])
                {
                    upperXYZ[1] = verts[i][1];
                }
                if(verts[i][2] < lowerXYZ[2])
                {
                    lowerXYZ[2] = verts[i][2];
                }
                if(verts[i][2] > upperXYZ[2])
                {
                    upperXYZ[2] = verts[i][2];
                }
            }
            
            centroid = [(upperXYZ[0] - lowerXYZ[0]) / 2, (upperXYZ[1] - lowerXYZ[1]) / 2, (upperXYZ[2] - lowerXYZ[2]) / 2 ];

            var centr = document.getElementById("centroid");
            centr.innerHTML = centroid;


                        
      
            relativeScaling[0] = 1 / (upperXYZ[0] - lowerXYZ[0]) / 3 ;
            relativeScaling[1] = 1 / (upperXYZ[1] - lowerXYZ[1]) / 3;
            relativeScaling[2] = 1 / (upperXYZ[2] - lowerXYZ[2]) / 3;

            scale[0] = relativeScaling[0];
            scale[1] = relativeScaling[1];
            scale[2] = relativeScaling[2];

            
            
            var program = initShaders(gl, "vertex-shader", "fragment-shader");
            gl.useProgram(program);

            var cBuffer = gl.createBuffer();
            gl.bindBuffer(gl.ARRAY_BUFFER, cBuffer);
            gl.bufferData(gl.ARRAY_BUFFER, flatten(colors), gl.STATIC_DRAW);

            var colorLoc = gl.getAttribLocation( program, "aColor" );
            gl.vertexAttribPointer( colorLoc, 4, gl.FLOAT, false, 0, 0 );
            gl.enableVertexAttribArray( colorLoc );

            var vBuffer = gl.createBuffer();
            gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
            gl.bufferData(gl.ARRAY_BUFFER, flatten(positions), gl.STATIC_DRAW);

            var positionLoc = gl.getAttribLocation(program, "aPosition");
            gl.vertexAttribPointer(positionLoc, 4, gl.FLOAT, false, 0, 0);
            gl.enableVertexAttribArray(positionLoc);

            thetaLoc = gl.getUniformLocation(program, "uTheta");
            translationLoc = gl.getUniformLocation(program, "translation");
            scaleLoc = gl.getUniformLocation(program, "scale");
            
            render();
            var rate = document.getElementById("output");
            rate.innerHTML = positions;

        }
        reader.readAsText(file);
    }
    
    //event listeners for buttons

    var tTypeId = document.getElementById( "TransformationType" )
    tTypeId.onclick = function() {
        tType = tTypeId.selectedIndex - 1;
    }

}

function render()
{
    gl.clear( gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    gl.uniform3fv(scaleLoc, scale);
    gl.uniform3fv(thetaLoc, theta);
    gl.uniform3fv(translationLoc, translate);

    gl.drawArrays(gl.TRIANGLES, 0, positions.length);
    requestAnimationFrame(render);

}


window.addEventListener("keydown", function() {
    
    if(event.key == "p") // Increase delta
    {
        if(tType != 2)
        {
            deltaAmt[tType] += .1;
        }
        else
        {
            deltaAmt[tType] += .01;  
        }
    }
    else if(event.key == "o") // Decrease delta
    {
        if(tType != 2)
        {
            deltaAmt[tType] -= .1;
        }
        else
        {
            deltaAmt[tType] -= .01;
        }
    }
    if(deltaAmt[tType] <= 0)
    {
        //Prevent delta from going negative
        deltaAmt[tType] = 0.1;
    }



    var deltaVec = [0,0,0];
    switch (event.key) {
        
    case "w": // Increase x
        deltaVec[0] += deltaAmt[tType];
        break;
    case "s": // Decrease x
        deltaVec[0] -= deltaAmt[tType];
        break;
    case "d": // Increase y
        deltaVec[1] += deltaAmt[tType];
        break;
    case "a": // Decrease y
        deltaVec[1] -= deltaAmt[tType];
        break;
    case "0": // Increase z
        deltaVec[2] += deltaAmt[tType];
        break;
    case "9": // Decrease z
        deltaVec[2] -= deltaAmt[tType];
        break;
    case "r": //Reset all values
        theta = [0, 0, 0];
        translate = centroid;
        scale = relativeScaling;
        deltaAmt = [1,1,1];
        break;
    default:
        break;
    }

    if(tType == 0)
    {
        scale[0] = deltaVec[0] + scale[0];
        scale[1] = deltaVec[1] + scale[1];
        scale[2] = deltaVec[2] + scale[2];
        
    }
    else if(tType == 1)
    {
        theta[0] = deltaVec[0] + theta[0];
        theta[1] = deltaVec[1] + theta[1];
        theta[2] = deltaVec[2] + theta[2];
        
    }
    else if(tType == 2)
    {
        translate[0] = deltaVec[0] + translate[0];
        translate[1] = deltaVec[1] + translate[1];
        translate[2] = deltaVec[2] + translate[2];
    }


    var rate = document.getElementById("output");
    rate.innerHTML = deltaAmt[tType];

    var translateCoords = document.getElementById("translation");
    translateCoords.innerHTML = translate;

});


function divideForAveraging(value1, value2)
{
    return vec3(value1[0]/value2[0], value1[1]/value2[1], value1[2]/value2[2])
}